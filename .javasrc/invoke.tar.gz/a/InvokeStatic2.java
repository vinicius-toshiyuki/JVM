package a;
public class InvokeStatic2{
	public static void metodo(int a){
		System.out.println("Olha o static2");
		System.out.println(a);
		System.out.println("Fim do static2");
	}
}
