import a.InvokeStatic2;
public class InvokeStatic{
	public static void main(String[] args){
		InvokeStatic2 a = new InvokeStatic2();
		a.metodo(3);
	}
}
